"use client";
import { useSearchParams } from 'next/navigation';
import styles from './PaymentFailed.module.css';

export default function PaymentFailed() {
  const searchParams = useSearchParams();
  const paymentId = searchParams.get('paymentId');

  return (
    <div className={styles.container}>
      <div className={styles.card}>
        <h1 className={styles.heading}>Payment Failed</h1>
        <div className={styles.icon}>❌</div>
        <p className={styles.message}>
          Your payment was cancelled or interrupted.
        </p>
        <p className={styles.paymentId}>
          Payment ID: {paymentId}
        </p>
      </div>
    </div>
  );
}