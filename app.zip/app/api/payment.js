const express = require('express');
const router = express.Router();
const bcrypt = require('bcrypt');
const { MongoClient } = require('mongodb');

const uri = "mongodb://localhost:27017";
const client = new MongoClient(uri);

router.post('/payment', async (req, res) => {
    try {
        const { payment_id, user_id, status, amount, created_at } = req.body;

        // Validate required fields
        if (!payment_id || !user_id || !status || !amount || !created_at) {
            return res.status(400).json({ error: 'All fields are required' });
        }

        await client.connect();
        const database = client.db('dininit_monitoring');
        const payment_status = database.collection('payment_status');

        // Check if payment_id exists
        const existingPayment = await payment_status.findOne({ payment_id });
        if (existingPayment) {
            return res.status(400).json({ error: 'Payment Already Exists' });
        }

        // Create new payment record
        const paymentData = {
            payment_id,
            user_id,
            status,
            amount,
            created_at: new Date()
        };

        await payment_status.insertOne(paymentData);
        
        res.status(201).json({ message: 'Payment Registered Successfully' });

    } catch (error) {
        console.error('Payment error:', error);
        res.status(500).json({ error: 'Internal server error' });
    } finally {
        await client.close();
    }
});

module.exports = router;