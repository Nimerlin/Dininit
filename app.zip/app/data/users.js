// data/users.js (Mock database)

export const users = [
    {
      email: 'user@example.com',
      password: 'password123' // Store plain-text password (again, not recommended)
    }
  ];