"use client";
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import styles from './DummyPayment.module.css';
import { IoClose } from "react-icons/io5";

export default function DummyPayment() {
  const [upiId, setUpiId] = useState('');
  const [paymentId, setPaymentId] = useState('');
  const [isValidUpi, setIsValidUpi] = useState(true);
  const [loading, setLoading] = useState(false);
  const [username, setUsername] = useState(''); // State for the username
  const router = useRouter();

  useEffect(() => {
    // Retrieve name from localStorage's user object
    const getUserFromStorage = () => {
      const storedUser = localStorage.getItem("user");
      if (storedUser) {
        const user = JSON.parse(storedUser);
        console.log('Retrieved user from storage:', user); // Debug log
        if (user.name) {
          setUsername(user.name);
        } else {
          console.log('No name found in user data, redirecting to login');
          router.push('/login');
        }
      } else {
        console.log('No user found in storage, redirecting to login');
        router.push('/login');
      }
    };

    const generatePaymentId = () => {
      const array = new Uint8Array(8);
      crypto.getRandomValues(array);
      const hexString = Array.from(array)
        .map(b => b.toString(16).padStart(2, '0'))
        .join('');
      setPaymentId(hexString);
      sessionStorage.setItem('currentPaymentId', hexString);
    };

    getUserFromStorage();
    generatePaymentId();
  }, [router]);

  useEffect(() => {
    // Handle refresh and navigation attempts
    const handleBeforeUnload = (e) => {
      e.preventDefault();
      e.returnValue = '';
      return '';
    };

    const handlePopState = () => {
      const confirmed = window.confirm(
        'Are you sure you want to leave? This will cancel your payment.'
      );

      if (confirmed) {
        sessionStorage.setItem('paymentStatus', 'cancelled');
        savePaymentStatus('cancelled');
        router.push(`/payment-failed?paymentId=${paymentId}`);
      } else {
        window.history.pushState(null, '', window.location.href);
      }
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    window.addEventListener('popstate', handlePopState);
    window.history.pushState(null, '', window.location.href);

    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
      window.removeEventListener('popstate', handlePopState);
    };
  }, [paymentId, router]);

  const validateUpiId = (upi) => {
    const upiRegex = /^[a-zA-Z0-9._-]+@[a-zA-Z]{3,}$/;
    return upiRegex.test(upi);
  };

  const handleUpiChange = (e) => {
    const value = e.target.value.trim();
    setUpiId(value);
    setIsValidUpi(value ? validateUpiId(value) : true);
  };

  const savePaymentStatus = async (status) => {
    try {
      const response = await fetch('http://localhost:3001/api/payment', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          payment_id: paymentId,
          user_id: username,
          status,
          amount: 499,
          created_at: new Date().toISOString(),
        }),
      });

      const responseData = await response.json();
      console.log('Server response:', responseData); // Log the server response

      if (!response.ok) {
        throw new Error(responseData.error || 'Failed to save payment status');
      }

      return responseData;
    } catch (error) {
      console.error('Error saving payment status:', error.message);
      throw error;
    }
  };

  const handlePayment = async () => {
    setLoading(true);
    console.log(`Processing payment with ID: ${paymentId}`);

    try {
      setTimeout(async () => {
        const isSuccess = Math.random() > 0.5;
        const status = isSuccess ? 'success' : 'failed';
        
        try {
          await savePaymentStatus(status);
          setLoading(false);
          
          if (isSuccess) {
            router.push('/services');
          } else {
            router.push(`/payment-failed?paymentId=${paymentId}`);
          }
        } catch (error) {
          setLoading(false);
          // Handle the error appropriately, maybe show an error message to the user
          console.error('Payment processing failed:', error);
          router.push(`/payment-failed?paymentId=${paymentId}`);
        }
      }, 2000);
    } catch (error) {
      setLoading(false);
      console.error('Payment processing failed:', error);
      router.push(`/payment-failed?paymentId=${paymentId}`);
    }
  };

  const handleCancel = async () => {
    const confirmed = window.confirm(
      'Are you sure you want to leave? This will cancel your payment.'
    );

    if (confirmed) {
      await savePaymentStatus('cancelled');
      router.push(`/payment-failed?paymentId=${paymentId}`);
    }
  };

  return (
    <div className={styles.container}>
      <div className={styles.card}>
        <div className={styles.header}>
          <h1 className={styles.heading}>Enter UPI ID</h1>
          <div className={styles.cancelIcon} onClick={handleCancel}>
            <IoClose size={24} color="red" />
          </div>
        </div>
        <input
          type="text"
          placeholder="example@upi"
          value={upiId}
          onChange={handleUpiChange}
          className={`${styles.input} ${!isValidUpi && upiId ? styles.error : ''}`}
        />
        {!isValidUpi && upiId && (
          <p className={styles.errorText}>Please enter a valid UPI ID</p>
        )}
        <button
          className={`${styles.button} ${loading ? styles.loading : ''}`}
          onClick={handlePayment}
          disabled={!upiId || loading || !isValidUpi}
        >
          {loading ? 'Processing...' : 'Pay ₹499'}
        </button>
        <p className={styles.paymentId}>Payment ID: {paymentId}</p>
      </div>
    </div>
  );
}
