
// pages/index.js
import React from 'react';
// import LandingPage from "../components/LandingPage";
import LandingPage from './components/LandingPage/landingPage';

export default function Home() {
  return <LandingPage />;
}
